package tv.own.owntv.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.tv.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/** Lightweight overlay for the AI-generated live subtitle. */
@Composable
fun AiSubtitleOverlay(
    engine: LivePreviewEngine,
    modifier: Modifier = Modifier,
    sizeScale: Float = 1f,
) {
    val text by engine.aiSubtitleText.collectAsStateWithLifecycle()
    val line = text?.takeIf { it.isNotBlank() } ?: return
    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp * sizeScale, vertical = 56.dp * sizeScale),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Text(
            text = line,
            textAlign = TextAlign.Center,
            color = Color.White,
            fontSize = (22f * sizeScale).sp,
            lineHeight = (28f * sizeScale).sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .widthIn(max = 1100.dp * sizeScale)
                .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
                .padding(horizontal = 16.dp * sizeScale, vertical = 6.dp * sizeScale),
        )
    }
}
