package tv.own.owntv.player.ai

import android.content.Context
import android.util.Log
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import dev.ffmpegkit.whisper.WhisperResult
import dev.ffmpegkit.whisper.WhisperModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/**
 * OwnTV's first-run multilingual Whisper model manager.
 *
 * One multilingual model covers English/French/German/Spanish/Italian and many more languages;
 * we deliberately do not download five separate language models. The model is stored in the app's
 * private files directory and survives normal app updates.
 */
object WhisperModelManager {
    private const val TAG = "OwnTV-Whisper"
    private const val MODEL_DIR = "whisper-models"
    private const val DEFAULT_MODEL = "tiny"
    private const val BASE_MODEL = "base"
    private const val TINY_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.bin?download=true"
    private const val BASE_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin?download=true"

    sealed interface State {
        data object Idle : State
        data class Downloading(val model: String, val percent: Int) : State
        data class Ready(val model: String) : State
        data class Error(val message: String) : State
    }

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()
    private val downloading = AtomicBoolean(false)
    @Volatile private var appContext: Context? = null
    @Volatile private var loadedModelName: String? = null
    @Volatile private var loadedModel: WhisperModel? = null

    fun initialize(context: Context) {
        appContext = context.applicationContext
    }

    /** The published whisper-android AAR currently ships native code for arm64-v8a only.
     * Keep non-arm64 builds from attempting to load the native library. */
    fun isSupportedAbi(): Boolean = android.os.Build.SUPPORTED_ABIS.any { it == "arm64-v8a" }

    fun modelFile(context: Context, model: String): File =
        File(File(context.filesDir, MODEL_DIR), "ggml-${normalizeModel(model)}.bin")

    fun isReady(context: Context, model: String): Boolean = modelFile(context, model).isFile && modelFile(context, model).length() > 1024L * 1024L

    suspend fun ensureModel(context: Context, model: String = DEFAULT_MODEL): Boolean = withContext(Dispatchers.IO) {
        initialize(context)
        AiSubtitleDiagnosticsLog.init(context)
        AiSubtitleDiagnosticsLog.event("model:ensure requested=$model abi=${android.os.Build.SUPPORTED_ABIS.joinToString(",")}")
        if (!isSupportedAbi()) {
            AiSubtitleDiagnosticsLog.warn("model:unsupported-abi")
            _state.value = State.Error("Whisper requires arm64-v8a")
            return@withContext false
        }
        val normalized = normalizeModel(model)
        val file = modelFile(context, normalized)
        if (file.isFile && file.length() > 1024L * 1024L) {
            AiSubtitleDiagnosticsLog.event("model:ready existing=$normalized bytes=${file.length()}")
            _state.value = State.Ready(normalized)
            return@withContext true
        }
        if (!downloading.compareAndSet(false, true)) {
            AiSubtitleDiagnosticsLog.event("model:download-already-running model=$normalized")
            return@withContext false
        }
        try {
            val dir = file.parentFile ?: return@withContext false
            dir.mkdirs()
            val tmp = File(dir, file.name + ".part")
            AiSubtitleDiagnosticsLog.event("model:download-start model=$normalized url=${modelUrl(normalized).substringBefore("?")}")
            val started = System.nanoTime()
            download(modelUrl(normalized), tmp) { percent ->
                _state.value = State.Downloading(normalized, percent)
                if (percent == 0 || percent == 25 || percent == 50 || percent == 75 || percent == 100) AiSubtitleDiagnosticsLog.event("model:download-progress model=$normalized percent=$percent")
            }
            if (tmp.length() <= 1024L * 1024L) error("Whisper model download is incomplete")
            if (file.exists()) file.delete()
            if (!tmp.renameTo(file)) error("Unable to finalize Whisper model")
            AiSubtitleDiagnosticsLog.event("model:download-done model=$normalized bytes=${file.length()} elapsedMs=${(System.nanoTime() - started) / 1_000_000L}")
            _state.value = State.Ready(normalized)
            true
        } catch (t: Throwable) {
            AiSubtitleDiagnosticsLog.warn("model:download-failed model=$normalized", t)
            _state.value = State.Error(t.message ?: "Whisper model download failed")
            false
        } finally {
            downloading.set(false)
        }
    }

    suspend fun transcribe(
        context: Context,
        model: String,
        audioFile: File,
        language: String,
    ): WhisperResult? = withContext(Dispatchers.IO) {
        AiSubtitleDiagnosticsLog.event("asr:request model=$model language=$language fileBytes=${audioFile.length()}")
        val started = System.nanoTime()
        if (!ensureModel(context, model)) {
            AiSubtitleDiagnosticsLog.warn("asr:model-not-ready model=$model")
            return@withContext null
        }
        val normalized = normalizeModel(model)
        val path = modelFile(context, normalized).absolutePath
        val whisper = try {
            if (loadedModel == null || loadedModelName != normalized) {
                AiSubtitleDiagnosticsLog.event("asr:model-load-start model=$normalized bytes=${File(path).length()}")
                loadedModel?.let { runCatching { Whisper.releaseModel(it) } }
                loadedModel = Whisper.loadModel(context.applicationContext, path)
                loadedModelName = normalized
            }
            loadedModel
        } catch (t: Throwable) {
            AiSubtitleDiagnosticsLog.warn("asr:model-load-failed model=$normalized", t)
            loadedModel = null
            loadedModelName = null
            return@withContext null
        }
        if (whisper == null) return@withContext null
        runCatching {
            Whisper.transcribe(
                whisper,
                audioFile.absolutePath,
                WhisperConfig(language = language.ifBlank { "auto" }),
            )
        }.onSuccess { result ->
            AiSubtitleDiagnosticsLog.event("asr:request-done model=$normalized elapsedMs=${(System.nanoTime() - started) / 1_000_000L} chars=${result.text.length} text=${result.text.replace("\n", " ").take(160)}")
        }.onFailure { AiSubtitleDiagnosticsLog.warn("asr:request-failed model=$normalized elapsedMs=${(System.nanoTime() - started) / 1_000_000L}", it) }.getOrNull()
    }

    fun release() {
        loadedModel?.let { runCatching { Whisper.releaseModel(it) } }
        loadedModel = null
        loadedModelName = null
    }

    private fun normalizeModel(model: String): String = when (model.lowercase()) {
        BASE_MODEL -> BASE_MODEL
        else -> DEFAULT_MODEL
    }

    private fun modelUrl(model: String): String = if (normalizeModel(model) == BASE_MODEL) BASE_URL else TINY_URL

    private fun download(urlString: String, target: File, onProgress: (Int) -> Unit) {
        val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            requestMethod = "GET"
        }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}")
            val total = connection.contentLengthLong
            var read = 0L
            var last = -1
            connection.inputStream.use { input ->
                target.outputStream().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        output.write(buffer, 0, n)
                        read += n
                        if (total > 0) {
                            val p = ((read * 100L) / total).toInt().coerceIn(0, 100)
                            if (p != last) { last = p; onProgress(p) }
                        }
                    }
                }
            }
            onProgress(100)
        } finally {
            connection.disconnect()
        }
    }
}
