package tv.own.owntv.player.ai

import android.content.Context
import android.util.Log
import android.os.Build
import android.provider.MediaStore
import android.content.ContentValues
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Dedicated AI-subtitle diagnostics. Keeps verbose events both in Logcat and in a rolling file so
 * IPTV/Whisper/translation failures can be diagnosed after the fact. Secrets are never accepted
 * by this class; callers must pass redacted values.
 */
object AiSubtitleDiagnosticsLog {
    const val TAG = "OwnTV-AI"
    private const val MAX_EVENTS = 2500
    private const val MAX_FILE_BYTES = 1024 * 1024L
    private val lock = Any()
    private val ring = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)
    @Volatile private var enabled = true
    @Volatile private var file: File? = null

    fun init(context: Context) {
        if (file != null) return
        runCatching {
            val dir = File(context.filesDir, "diagnostics").apply { mkdirs() }
            file = File(dir, "ai_subtitle.log")
        }
    }

    fun setEnabled(value: Boolean) { enabled = value }

    fun event(message: String) {
        val line = "${fmt.format(Date())} $message"
        synchronized(lock) {
            ring.addLast(line)
            while (ring.size > MAX_EVENTS) ring.pollFirst()
        }
        if (!enabled) return
        Log.i(TAG, message)
        runCatching {
            val f = file ?: return@runCatching
            if (f.exists() && f.length() > MAX_FILE_BYTES) {
                val kept = f.readLines().takeLast(MAX_EVENTS / 2)
                f.writeText(kept.joinToString("\n") + "\n")
            }
            f.appendText(line + "\n")
        }
    }

    fun warn(message: String, error: Throwable? = null) {
        val suffix = error?.let { " | ${it.javaClass.simpleName}: ${it.message}" } ?: ""
        event("WARN $message$suffix")
        if (enabled && error != null) Log.w(TAG, message, error)
    }

    fun snapshot(): String = synchronized(lock) { ring.joinToString("\n") }

    fun clear(context: Context? = null) {
        synchronized(lock) { ring.clear() }
        runCatching {
            (file ?: context?.let { init(it); file })?.writeText("")
        }
        event("diagnostics:cleared")
    }

    /**
     * Exports a shareable ZIP into the public Download/OwnTV directory via MediaStore.
     * No storage permission is required on Android 10+ for files created by this app.
     * Secrets are intentionally not accepted here; callers provide only sanitized metadata.
     */
    fun exportDiagnostics(context: Context, metadata: Map<String, String> = emptyMap()): android.net.Uri? {
        init(context)
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val displayName = "OwnTV-AI-diagnostics-$stamp.zip"
        val temp = File(context.cacheDir, displayName)
        val logText = runCatching { file?.takeIf { it.exists() }?.readText() }.getOrNull().orEmpty()
            .ifBlank { snapshot() }
        val meta = buildString {
            appendLine("OwnTV AI Subtitle diagnostics")
            appendLine("created=$stamp")
            appendLine("package=${context.packageName}")
            appendLine("android=${Build.VERSION.RELEASE} (${Build.VERSION.SDK_INT})")
            appendLine("device=${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("abis=${Build.SUPPORTED_ABIS.joinToString(",")}")
            metadata.toSortedMap().forEach { (k, v) -> appendLine("$k=$v") }
            appendLine()
            appendLine("Sensitive values such as API keys, cookies and tokens are intentionally excluded.")
        }
        runCatching {
            ZipOutputStream(temp.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry("diagnostics.txt")); zip.write(meta.toByteArray()); zip.closeEntry()
                zip.putNextEntry(ZipEntry("ai_subtitle.log")); zip.write(logText.toByteArray()); zip.closeEntry()
            }
        }.getOrElse { return null }

        return runCatching {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/OwnTV")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return@runCatching null
            try {
                resolver.openOutputStream(uri)?.use { out -> temp.inputStream().use { it.copyTo(out) } }
                    ?: error("Unable to open exported diagnostic file")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
                }
                uri
            } catch (t: Throwable) {
                resolver.delete(uri, null, null)
                throw t
            } finally {
                temp.delete()
            }
        }.getOrNull()
    }

    fun file(): File? = file
}
