package tv.own.owntv.player.ai

import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import java.net.URLEncoder

/**
 * Decoded-PCM tap for AI live subtitles.
 *
 * The processor is deliberately transparent: the same PCM bytes continue to the AudioSink while a
 * copy is accumulated for speech recognition. No second IPTV request is made.
 *
 * This first implementation intentionally handles only 16-bit PCM. Live IPTV AAC/AC-3/E-AC-3
 * streams decoded by Media3 normally arrive here as PCM; if a device/codec produces another PCM
 * representation, the processor stays inactive rather than risking playback corruption.
 */
class AiSubtitleAudioProcessor(
    private val enabled: () -> Boolean,
    private val apiKey: () -> String,
    private val apiBaseUrl: () -> String = { "https://api.deepseek.com" },
    private val apiModel: () -> String = { "deepseek-flash" },
    private val thinkingEnabled: () -> Boolean = { false },
    private val asrModel: () -> String = { "tiny" },
    private val asrLanguage: () -> String = { "auto" },
    private val cacheDir: File,
    private val targetLanguage: () -> String = { "zh-CN" },
    private val bilingual: () -> Boolean = { true },
    private val context: android.content.Context,
) : AudioProcessor {

    companion object {
        private const val TAG = "OwnTV-AI"
        private const val SEGMENT_MS = 3000L
        private const val SUBTITLE_HOLD_MS = 6500L
        private val JSON = "application/json; charset=utf-8".toMediaType()
    }

    private data class Segment(
        val generation: Long,
        val pcm: ByteArray,
        val sampleRate: Int,
        val channels: Int,
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val queue = Channel<Segment>(Channel.CONFLATED)
    @Volatile private var released = false
    private val generation = AtomicLong(0L)
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val _subtitle = MutableStateFlow<String?>(null)
    val subtitle: StateFlow<String?> = _subtitle.asStateFlow()

    private var subtitleClearJob: Job? = null
    private var inputFormat = AudioFormat.NOT_SET
    private var outputBuffer: ByteBuffer = ByteBuffer.allocateDirect(0)
    private var ended = false
    private val accumulator = ByteArrayOutputStream()
    private var accumulatedFrames = 0L

    init {
        WhisperModelManager.initialize(context)
        AiSubtitleDiagnosticsLog.init(context)
        AiSubtitleDiagnosticsLog.event("processor:init enabled=${enabled()} model=${asrModel()} lang=${asrLanguage()} target=${targetLanguage()} bilingual=${bilingual()}")
        scope.launch {
            for (segment in queue) {
                if (released || segment.generation != generation.get()) continue
                runCatching { process(segment) }
                    .onFailure { Log.w(TAG, "AI subtitle request failed", it) }
            }
        }
    }

    override fun configure(inputAudioFormat: AudioFormat): AudioFormat {
        inputFormat = inputAudioFormat
        accumulator.reset()
        accumulatedFrames = 0L
        ended = false
        val gen = generation.incrementAndGet()
        clearSubtitle()
        AiSubtitleDiagnosticsLog.event("audio:configure gen=$gen encoding=${inputAudioFormat.encoding} sampleRate=${inputAudioFormat.sampleRate} channels=${inputAudioFormat.channelCount} active=${isActive()} enabled=${enabled()}")
        return inputAudioFormat
    }

    override fun isActive(): Boolean =
        inputFormat != AudioFormat.NOT_SET &&
            inputFormat.encoding == C.ENCODING_PCM_16BIT &&
            inputFormat.sampleRate > 0 &&
            inputFormat.channelCount > 0

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!inputBuffer.hasRemaining()) return

        // Keep playback independent of the AI network path. The processor owns an output copy, so
        // the downstream AudioSink never depends on the lifetime of ExoPlayer's input buffer.
        val duplicate = inputBuffer.duplicate()
        val bytes = ByteArray(duplicate.remaining())
        duplicate.get(bytes)
        inputBuffer.position(inputBuffer.limit())

        outputBuffer = ByteBuffer.allocateDirect(bytes.size)
        outputBuffer.put(bytes)
        outputBuffer.flip()

        if (!enabled() || !isActive()) return

        val channels = inputFormat.channelCount
        val bytesPerFrame = channels * 2
        if (bytesPerFrame <= 0) return
        accumulator.write(bytes)
        accumulatedFrames += bytes.size.toLong() / bytesPerFrame
        val targetFrames = inputFormat.sampleRate.toLong() * SEGMENT_MS / 1000L
        if (accumulatedFrames >= targetFrames) {
            val chunk = accumulator.toByteArray()
            accumulator.reset()
            accumulatedFrames = 0L
            val sendResult = queue.trySend(
                Segment(
                    generation = generation.get(),
                    pcm = chunk,
                    sampleRate = inputFormat.sampleRate,
                    channels = channels,
                ),
            )
            if (sendResult.isFailure) AiSubtitleDiagnosticsLog.warn("queue:drop  gen=${generation.get()} bytes=${chunk.size}")
            else AiSubtitleDiagnosticsLog.event("queue:enqueue gen=${generation.get()} bytes=${chunk.size} durationMs=$SEGMENT_MS")
        }
    }

    override fun queueEndOfStream() {
        ended = true
        AiSubtitleDiagnosticsLog.event("audio:eos tailBytes=${accumulator.size()} gen=${generation.get()}")
        val tail = accumulator.toByteArray()
        accumulator.reset()
        accumulatedFrames = 0L
        if (tail.isNotEmpty() && enabled() && isActive()) {
            val sendResult = queue.trySend(
                Segment(
                    generation = generation.get(),
                    pcm = tail,
                    sampleRate = inputFormat.sampleRate,
                    channels = inputFormat.channelCount,
                ),
            )
            if (sendResult.isFailure) AiSubtitleDiagnosticsLog.warn("queue:drop tail bytes=${tail.size}")
            else AiSubtitleDiagnosticsLog.event("queue:enqueue tail bytes=${tail.size}")
        }
    }

    override fun getOutput(): ByteBuffer {
        val out = outputBuffer
        outputBuffer = ByteBuffer.allocateDirect(0)
        return out
    }

    override fun isEnded(): Boolean = ended && !outputBuffer.hasRemaining()

    override fun flush() {
        outputBuffer = ByteBuffer.allocateDirect(0)
        accumulator.reset()
        accumulatedFrames = 0L
        ended = false
        val gen = generation.incrementAndGet()
        clearSubtitle()
        AiSubtitleDiagnosticsLog.event("audio:flush gen=$gen")
    }

    override fun reset() {
        flush()
        inputFormat = AudioFormat.NOT_SET
        AiSubtitleDiagnosticsLog.event("audio:reset")
    }

    fun release() {
        if (released) return
        released = true
        generation.incrementAndGet()
        subtitleClearJob?.cancel()
        subtitleClearJob = null
        queue.close()
        scope.coroutineContext.cancel()
        _subtitle.value = null
        accumulator.reset()
        outputBuffer = ByteBuffer.allocateDirect(0)
        AiSubtitleDiagnosticsLog.event("processor:release")
    }

    fun clearSubtitle() {
        if (released) return
        generation.incrementAndGet()
        subtitleClearJob?.cancel()
        subtitleClearJob = null
        _subtitle.value = null
        AiSubtitleDiagnosticsLog.event("subtitle:clear gen=${generation.get()}")
    }

    private suspend fun process(segment: Segment) {
        if (released || segment.generation != generation.get() || !enabled()) return
        val key = apiKey().trim()
        val started = System.nanoTime()
        AiSubtitleDiagnosticsLog.event("process:start gen=${segment.generation} bytes=${segment.pcm.size} rate=${segment.sampleRate} ch=${segment.channels} keyConfigured=${key.isNotBlank()}")

        val wav = File.createTempFile("owntv-ai-", ".wav", cacheDir)
        try {
            wav.writeBytes(
                wavHeader(
                    dataLength = segment.pcm.size,
                    sampleRate = segment.sampleRate,
                    channels = segment.channels,
                    bitsPerSample = 16,
                ) + segment.pcm,
            )

            AiSubtitleDiagnosticsLog.event("asr:start model=${asrModel()} language=${asrLanguage()}")
            val asrStarted = System.nanoTime()
            val transcription = WhisperModelManager.transcribe(
                context = context,
                model = asrModel(),
                audioFile = wav,
                language = asrLanguage().ifBlank { "auto" },
            )?.text?.trim()?.takeIf { it.isNotEmpty() } ?: run {
                AiSubtitleDiagnosticsLog.warn("asr:no-text elapsedMs=${elapsedMs(asrStarted)}")
                return
            }
            AiSubtitleDiagnosticsLog.event("asr:done elapsedMs=${elapsedMs(asrStarted)} chars=${transcription.length}")
            if (released || segment.generation != generation.get() || !enabled()) return

            // Translation is intentionally detached from the ASR worker. A slow LLM/HTTP fallback
            // must never make the next 3-second audio segment wait behind it.
            scope.launch {
                runCatching {
                    renderTranslation(segment, transcription, key, started)
                }.onFailure { Log.w(TAG, "AI translation failed", it) }
            }
        } finally {
            wav.delete()
            AiSubtitleDiagnosticsLog.event("process:end gen=${segment.generation} elapsedMs=${elapsedMs(started)}")
        }
    }

    private suspend fun renderTranslation(segment: Segment, transcription: String, key: String, started: Long) {
        if (released || segment.generation != generation.get() || !enabled()) return
        val target = targetLanguage().ifBlank { "zh-CN" }
        // Do not use the user-selected ASR hint as a detected source language. It is only a hint
        // passed to Whisper; otherwise forcing `zh` could incorrectly suppress translation of English.
        val sourceIsChinese = isChineseText(transcription)
        val targetIsChinese = target.substringBefore('-').equals("zh", ignoreCase = true)
        AiSubtitleDiagnosticsLog.event("translation:policy sourceChinese=$sourceIsChinese targetChinese=$targetIsChinese target=$target")
        val translated = if (sourceIsChinese && targetIsChinese) {
            AiSubtitleDiagnosticsLog.event("translation:skip chinese-direct")
            transcription
        } else {
            translateWithFallback(
                key = key,
                text = transcription,
                target = target,
                baseUrl = apiBaseUrl(),
                model = apiModel(),
                thinking = thinkingEnabled(),
            ) ?: transcription
        }
        if (released || segment.generation != generation.get() || !enabled()) return

        val rendered = if (bilingual() && translated != transcription) {
            "$transcription\n$translated"
        } else {
            translated
        }
        AiSubtitleDiagnosticsLog.event("subtitle:show chars=${rendered.length} bilingual=${bilingual()} totalElapsedMs=${elapsedMs(started)}")
        _subtitle.value = rendered
        val visibleGeneration = generation.get()
        subtitleClearJob?.cancel()
        subtitleClearJob = scope.launch {
            delay(SUBTITLE_HOLD_MS)
            if (!released && visibleGeneration == generation.get()) {
                _subtitle.value = null
                AiSubtitleDiagnosticsLog.event("subtitle:auto-clear gen=$visibleGeneration")
            }
        }
    }

    /**
     * Translation policy: use the configured OpenAI-compatible model (DeepSeek by default) when
     * a key is present; otherwise, or after a model failure, use the keyless Google Translate
     * endpoint used by many IPTV/translation clients. The Google endpoint is intentionally only a
     * fallback because it is not the supported Google Cloud Translation API and has no SLA.
     */
    private fun translateWithFallback(
        key: String,
        text: String,
        target: String,
        baseUrl: String,
        model: String,
        thinking: Boolean,
    ): String? {
        if (key.isNotBlank()) {
            runCatching {
                AiSubtitleDiagnosticsLog.event("translation:llm-start base=${safeUrl(baseUrl)} model=${model.ifBlank { "deepseek-flash" }} thinking=$thinking chars=${text.length}")
                val started = System.nanoTime()
                translateOpenAiCompatible(key, text, target, baseUrl, model, thinking).also {
                    AiSubtitleDiagnosticsLog.event("translation:llm-done elapsedMs=${elapsedMs(started)} chars=${it.length}")
                }
            }.onFailure { AiSubtitleDiagnosticsLog.warn("translation:llm-failed; trying Google fallback", it) }
                .getOrNull()?.takeIf { it.isNotBlank() }?.let { return it }
        }
        return runCatching {
            AiSubtitleDiagnosticsLog.event("translation:google-start target=$target chars=${text.length}")
            val started = System.nanoTime()
            translateGoogleFree(text, target).also { AiSubtitleDiagnosticsLog.event("translation:google-done elapsedMs=${elapsedMs(started)} chars=${it.length}") }
        }.onFailure { AiSubtitleDiagnosticsLog.warn("translation:google-failed", it) }
            .getOrNull()
    }

    private fun translateOpenAiCompatible(
        key: String,
        text: String,
        target: String,
        baseUrl: String,
        model: String,
        thinking: Boolean,
    ): String {
        val prompt = "Translate the following spoken subtitle into $target. " +
            "Preserve names, numbers and proper nouns. Return only the translation, with no explanation.\n\n$text"
        val messages = org.json.JSONArray()
            .put(JSONObject().put("role", "system").put("content", "You are a real-time subtitle translator. Return only the translated subtitle."))
            .put(JSONObject().put("role", "user").put("content", prompt))
        val payload = JSONObject()
            .put("model", model.ifBlank { "deepseek-flash" })
            .put("messages", messages)
            .put("temperature", 0.1)
            .put("max_tokens", 300)
        payload.put("thinking", JSONObject().put("type", if (thinking) "enabled" else "disabled"))

        val request = Request.Builder()
            .url(chatCompletionsUrl(baseUrl))
            .header("Authorization", "Bearer $key")
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody(JSON))
            .build()
        http.newCall(request).execute().use { response ->
            AiSubtitleDiagnosticsLog.event("translation:llm-http code=${response.code} success=${response.isSuccessful}")
            if (!response.isSuccessful) error("translation HTTP ${response.code}")
            val json = JSONObject(response.body?.string() ?: error("empty translation response"))
            val choices = json.optJSONArray("choices") ?: error("missing choices")
            val message = choices.optJSONObject(0)?.optJSONObject("message") ?: error("missing message")
            return message.optString("content").trim().takeIf { it.isNotEmpty() }
                ?: error("empty translation")
        }
    }

    private fun translateGoogleFree(text: String, target: String): String {
        val language = target.substringBefore('-').ifBlank { "zh" }
        val encoded = URLEncoder.encode(text, Charsets.UTF_8.name())
        val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$language&dt=t&q=$encoded"
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "OwnTV/5.0 (Android TV)")
            .get()
            .build()
        http.newCall(request).execute().use { response ->
            AiSubtitleDiagnosticsLog.event("translation:google-http code=${response.code} success=${response.isSuccessful}")
            if (!response.isSuccessful) error("Google translation HTTP ${response.code}")
            val body = response.body?.string() ?: error("empty Google translation response")
            val root = org.json.JSONArray(body)
            val chunks = root.optJSONArray(0) ?: error("invalid Google translation response")
            val result = buildString {
                for (i in 0 until chunks.length()) {
                    val chunk = chunks.optJSONArray(i) ?: continue
                    append(chunk.optString(0))
                }
            }.trim()
            return result.takeIf { it.isNotEmpty() } ?: error("empty Google translation")
        }
    }

    private fun chatCompletionsUrl(base: String): String {
        val trimmed = base.trim().trimEnd('/')
        return when {
            trimmed.endsWith("/chat/completions") -> trimmed
            else -> "$trimmed/chat/completions"
        }
    }

    /** Heuristic used only to avoid translating text that is already Chinese. */
    private fun isChineseText(text: String): Boolean {
        if (text.isBlank()) return false
        var cjk = 0
        var letters = 0
        for (ch in text) {
            when {
                ch in '\u3400'..'\u4DBF' || ch in '\u4E00'..'\u9FFF' ||
                    ch in '\uF900'..'\uFAFF' -> cjk++
                ch.isLetter() -> letters++
            }
        }
        val denominator = (cjk + letters).coerceAtLeast(1)
        return cjk >= 3 && cjk.toDouble() / denominator >= 0.20
    }


    private fun elapsedMs(started: Long): Long = (System.nanoTime() - started) / 1_000_000L

    private fun safeText(text: String): String = text.replace("\n", " ").take(160)

    private fun safeUrl(url: String): String = runCatching {
        val u = java.net.URI(url.trim())
        "${u.scheme ?: ""}://${u.host ?: ""}${u.path ?: ""}"
    }.getOrDefault("<invalid-url>")

    private fun wavHeader(dataLength: Int, sampleRate: Int, channels: Int, bitsPerSample: Int): ByteArray {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8
        return ByteBuffer.allocate(44)
            .order(ByteOrder.LITTLE_ENDIAN)
            .put("RIFF".toByteArray(Charsets.US_ASCII))
            .putInt(36 + dataLength)
            .put("WAVE".toByteArray(Charsets.US_ASCII))
            .put("fmt ".toByteArray(Charsets.US_ASCII))
            .putInt(16)
            .putShort(1)
            .putShort(channels.toShort())
            .putInt(sampleRate)
            .putInt(byteRate)
            .putShort(blockAlign.toShort())
            .putShort(bitsPerSample.toShort())
            .put("data".toByteArray(Charsets.US_ASCII))
            .putInt(dataLength)
            .array()
    }
}
